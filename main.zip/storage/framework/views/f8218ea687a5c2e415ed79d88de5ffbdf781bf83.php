<!-- Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder'=>'Name']); ?>

</div>

<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::text('email', null, ['class' => 'form-control', 'placeholder'=>'Email']); ?>

</div>

<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Password:'); ?>

    <?php echo Form::password('password',array('placeholder'=>'Password','class' => 'form-control')); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Cancel</a>
</div>
<?php /**PATH D:\php74\htdocs\passport\resources\views/users/fields.blade.php ENDPATH**/ ?>