<div class="table-responsive-sm">
    <table class="table table-striped" id="payments-table">
        <thead>
            <tr>
                <th>Total Amount</th>
                <th>Passport no</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($payment->total_amount); ?></td>
                <td><?php echo e((isset($payment->passportjoin->passport_no)?$payment->passportjoin->passport_no:'None')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH D:\php74\htdocs\passport\resources\views/payments/report_table.blade.php ENDPATH**/ ?>