<!-- Passport Holder Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('passport_holder', 'Passport Holder:'); ?></strong>
    <p><?php echo e($passport->passport_holder); ?></p>
</div>

<!-- Holder Father Name Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('holder_father_name', 'Holder Father Name:'); ?></strong>
    <p><?php echo e($passport->holder_father_name); ?></p>
</div>

<!-- Passport No Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('passport_no', 'Passport No:'); ?></strong>
    <p><?php echo e($passport->passport_no); ?></p>
</div>

<!-- Position Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('position', 'Position:'); ?></strong>
    <p><?php echo e((isset($passport->positionjoin->title)?$passport->positionjoin->title:'None')); ?></p>
</div>

<!-- Issue Date Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('issue_date', 'Issue Date:'); ?></strong>
    <p><?php echo e($passport->issue_date); ?></p>
</div>

<!-- Expiry Date Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('expiry_date', 'Expiry Date:'); ?></strong>
    <p><?php echo e($passport->expiry_date); ?></p>
</div>

<!-- Date Of Birth Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('date_of_birth', 'Date Of Birth:'); ?></strong>
    <p><?php echo e($passport->date_of_birth); ?></p>
</div>

<!-- Mobile No Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('mobile_no', 'Mobile No:'); ?></strong>
    <p><?php echo e($passport->mobile_no); ?></p>
</div>

<!-- Selection Status Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('selection_status', 'Selection Status:'); ?></strong>
    <p><?php echo e((isset($passport->selectionStatusjoin->title)?$passport->selectionStatusjoin->title:'None')); ?></p>
</div>

<!-- Medical Issue Date Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('medical_issue_date', 'Medical Issue Date:'); ?></strong>
    <p><?php echo e($passport->medical_issue_date); ?></p>
</div>

<!-- Medical Status Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('medical_status', 'Medical Status:'); ?></strong>
    <p><?php echo e((isset($passport->medicalStatusjoin->title)?$passport->medicalStatusjoin->title:'None')); ?></p>
</div>

<!-- Medical Report Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('medical_report', 'Medical Report:'); ?></strong>
    <p><?php echo e((isset($passport->medicalReportjoin->title)?$passport->medicalReportjoin->title:'None')); ?></p>
</div>

<!-- Reference Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('reference', 'Reference:'); ?></strong>
    <p><?php echo e((isset($passport->referencejoin->name)?$passport->referencejoin->name:'None')); ?></p>
</div>

<!-- Company Name Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('company_name', 'Company Name:'); ?></strong>
    <p><?php echo e($passport->company_name); ?></p>
</div>

<!-- Agent Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('agent', 'Agent:'); ?></strong>
    <p><?php echo e((isset($passport->agentjoin->title)?$passport->agentjoin->title:'None')); ?></p>
</div>

<!-- Remarks Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('remarks', 'Remarks:'); ?></strong>
    <p><?php echo e($passport->remarks); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('created_at', 'Created At:'); ?></strong>
    <p><?php echo e($passport->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group col-md-6">
    <strong><?php echo Form::label('updated_at', 'Updated At:'); ?></strong>
    <p><?php echo e($passport->updated_at); ?></p>
</div>

<?php /**PATH D:\php74\htdocs\passport\resources\views/passports/show_fields.blade.php ENDPATH**/ ?>