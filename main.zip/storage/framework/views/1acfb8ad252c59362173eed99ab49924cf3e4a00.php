<!-- App Name Field -->
<div class="form-group">
    <?php echo Form::label('app_name', 'App Name:'); ?>

    <p><?php echo e($setting->app_name); ?></p>
</div>

<!-- App Title Field -->
<div class="form-group">
    <?php echo Form::label('app_title', 'App Title:'); ?>

    <p><?php echo e($setting->app_title); ?></p>
</div>

<!-- Address Field -->
<div class="form-group">
    <?php echo Form::label('address', 'Address:'); ?>

    <p><?php echo e($setting->address); ?></p>
</div>

<!-- Phone Field -->
<div class="form-group">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <p><?php echo e($setting->phone); ?></p>
</div>

<!-- App Email Field -->
<div class="form-group">
    <?php echo Form::label('app_email', 'App Email:'); ?>

    <p><?php echo e($setting->app_email); ?></p>
</div>

<!-- App Logo Field -->
<div class="form-group">
    <?php echo Form::label('app_logo', 'App Logo:'); ?>

    <img src="<?php echo e(asset('/storage/'. $setting->app_logo )); ?>" width="30" height="40">
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($setting->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($setting->updated_at); ?></p>
</div>

<?php /**PATH D:\php74\htdocs\passport\resources\views/settings/show_fields.blade.php ENDPATH**/ ?>