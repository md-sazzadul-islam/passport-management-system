<!-- Amount Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <?php echo Form::text('amount', null, ['class' => 'form-control']); ?>

</div>

<!-- Passport Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('passport', 'Passport:'); ?>

    <?php echo Form::select('passport', $passport, null, ['class' => 'form-control', 'placeholder' => 'Please Select Passport']); ?>

</div>

<!-- Date Field -->
<div class="form-group col-sm-6 col-lg-6">
    <?php echo Form::label('date', 'Date:'); ?>

    <?php echo Form::date('date', null, ['class' => 'form-control']); ?>

</div>

<!-- Note Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('note', 'Note:'); ?>

    <?php echo Form::textarea('note', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('payments.index')); ?>" class="btn btn-secondary">Cancel</a>
</div>
<?php /**PATH D:\php74\htdocs\passport\resources\views/payments/fields.blade.php ENDPATH**/ ?>