<li class="nav-item <?php echo e(Request::is('home*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('home')); ?>">
        <i class="nav-icon icon-speedometer"></i>
        <span>Dashboard</span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('positions*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('positions.index')); ?>">
        <i class="nav-icon icon-directions"></i>
        <span>Positions</span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('selectionStatuses*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('selectionStatuses.index')); ?>">
        <i class="nav-icon icon-direction"></i>
        <span>Selection Status</span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('references*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('references.index')); ?>">
        <i class="nav-icon icon-size-actual"></i>
        <span>References</span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('medicalStatuses*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('medicalStatuses.index')); ?>">
        <i class="nav-icon icon-briefcase"></i>
        <span>Medical Status</span>
    </a>
</li>
<li class="nav-item <?php echo e(Request::is('medicalReports*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('medicalReports.index')); ?>">
        <i class="nav-icon icon-calculator"></i>
        <span>Medical Report status</span>
    </a>
</li>
<li class="nav-item <?php echo e(Request::is('agents*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('agents.index')); ?>">
        <i class="nav-icon icon-rocket"></i>
        <span>Agents</span>
    </a>
</li>
<li class="nav-item <?php echo e(Request::is('passports*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('passports.index')); ?>">
        <i class="nav-icon icon-wallet"></i>
        <span>Passports list</span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('payments*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('payments.index')); ?>">
        <i class="nav-icon icon-paypal"></i>
        <span>Payments</span>
    </a>
</li>
<li class="nav-item <?php echo e(Request::is('payments*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('payment_report')); ?>">
        <i class="nav-icon icon-paypal"></i>
        <span>Payment report</span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('settings*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('settings.index')); ?>">
        <i class="nav-icon icon-settings"></i>
        <span>Settings</span>
    </a>
</li>
<li class="nav-item <?php echo e(Request::is('settings*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
        <i class="nav-icon icon-user"></i>
        <span>Users</span>
    </a>
</li>
<?php /**PATH D:\php74\htdocs\passport\resources\views/layouts/menu.blade.php ENDPATH**/ ?>