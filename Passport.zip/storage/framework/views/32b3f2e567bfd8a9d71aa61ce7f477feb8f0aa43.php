<div class="table-responsive-sm">
    <table class="table table-striped" id="settings-table">
        <thead>
            <tr>
                <th>App Name</th>
                <th>App Title</th>
                <th>Address</th>
                <th>Phone</th>
                <th>App Email</th>
                <th>App Logo</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($setting->app_name); ?></td>
                <td><?php echo e($setting->app_title); ?></td>
                <td><?php echo e($setting->address); ?></td>
                <td><?php echo e($setting->phone); ?></td>
                <td><?php echo e($setting->app_email); ?></td>
                <td>
                    <img src="<?php echo e(asset('public//storage/'. $setting->app_logo )); ?>" width="30" height="40">
                </td>
                <td>
                    <?php echo Form::open(['route' => ['settings.destroy', $setting->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('settings.show', [$setting->id])); ?>" class='btn btn-ghost-success'><i class="fa fa-eye"></i></a>
                        <a href="<?php echo e(route('settings.edit', [$setting->id])); ?>" class='btn btn-ghost-info'><i class="fa fa-edit"></i></a>
                        <!-- <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-ghost-danger', 'onclick' => "return confirm('Are you sure?')"]); ?> -->
                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH D:\php74\htdocs\passport\resources\views/settings/table.blade.php ENDPATH**/ ?>