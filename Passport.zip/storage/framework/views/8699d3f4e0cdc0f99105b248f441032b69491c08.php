<div class="table-responsive-sm">
    <table class="table table-striped" id="passports-table">
        <thead>
            <tr>
                <th>Passport Holder</th>
                <th>Passport No</th>
                <th>Position</th>
                <th>Mobile No</th>
                <th>Selection Status</th>
                <th>Medical Status</th>
                <th>Medical Report</th>
                <th>Reference</th>
                <th>Agent</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $passports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($passport->passport_holder); ?></td>
                <td><?php echo e($passport->passport_no); ?></td>
                <td><?php echo e((isset($passport->positionjoin->title)?$passport->positionjoin->title:'None')); ?></td>
                <td><?php echo e($passport->mobile_no); ?></td>
                <td><?php echo e((isset($passport->selectionStatusjoin->title)?$passport->selectionStatusjoin->title:'None')); ?></td>
                <td><?php echo e((isset($passport->medicalStatusjoin->title)?$passport->medicalStatusjoin->title:'None')); ?></td>
                <td><?php echo e((isset($passport->medicalReportjoin->title)?$passport->medicalReportjoin->title:'None')); ?></td>
                <td><?php echo e((isset($passport->referencejoin->name)?$passport->referencejoin->name:'None')); ?></td>
                <td><?php echo e((isset($passport->agentjoin->title)?$passport->agentjoin->title:'None')); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['passports.destroy', $passport->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('passports.show', [$passport->id])); ?>" class='btn btn-ghost-success'><i class="fa fa-eye"></i></a>
                        <a href="<?php echo e(route('passports.edit', [$passport->id])); ?>" class='btn btn-ghost-info'><i class="fa fa-edit"></i></a>
                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-ghost-danger', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH D:\php74\htdocs\passport\resources\views/passports/table.blade.php ENDPATH**/ ?>