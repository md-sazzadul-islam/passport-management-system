<!-- Title Field -->
<div class="form-group">
    <?php echo Form::label('title', 'Title:'); ?>

    <p><?php echo e($agent->title); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($agent->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($agent->updated_at); ?></p>
</div>

<?php /**PATH D:\php74\htdocs\passport\resources\views/agents/show_fields.blade.php ENDPATH**/ ?>